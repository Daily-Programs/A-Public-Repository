#include <iostream>
using namespace std;

void primes(int limit);

int main(int argc, char *argv[])
{
    for (int i = 1; i < 10; i ++) 
	primes(i);

    exit(0);

} /* end main() */
