#include <iostream>
using namespace std;
/*Mona added this to test the GitHub change notification within the Read the Docs and GradeScope
void primes(int limit);

int main(int argc, char *argv[])
{
    for (int i = 1; i < 10; i ++) 
	primes(i);

    exit(0);

} /* end main() */
